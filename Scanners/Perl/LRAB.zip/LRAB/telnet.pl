#!/usr/bin/perl

##
## Tscan v2.0 by Daenerys Tygarian 
## Last official update: 14/11/2011
##

## Import statements
use IO::Socket;
use Term::ANSIColor;
use Shell;
use Getopt::Long;

## Options
my $verbose = '';
my $rangeGe = '';

GetOptions ('v' => \$verbose,
        'ip=s' => \$rangeGe);

system(clear);

print "--\n";
print "-- tScan v2.0 --\n";
print "-- By Daenerys Tygarian  ---\n";
print "--\n";
print "\n\n";
print "use the '-v' option to see the IP-addresses";
print "\n";
print "that are being scanned. Use the '-ip' option to";
print "\n";
print "specify a network, like: 139.4.x.x";
print "\n";
print "These networks aren't checked, so enter a good one.";
print "\n\n";

#### Range IP Generator ####
sub rangeIPGenerator() {
    $range1 = 254;
    @octs = split(/\./,$rangeGe);

    if (@octs[0] eq 'x') {
        @octs[0] = int(rand($range1)) + 1;
    }
    if (@octs[1] eq 'x') {
    @octs[1] = int(rand($range1)) + 1;
  }
    if (@octs[2] eq 'x') {
    @octs[2] = int(rand($range1)) + 1;
  }
    if (@octs[3] eq 'x') {
    @octs[3] = int(rand($range1)) + 1;
  }

    $ip = "@octs[0].@octs[1].@octs[2].@octs[3]";
    return $ip;

}

#### Random IP Generator ####
sub randomIPGenerator() {
    $range1 = 254;

    $oct1 = int(rand($range1)) + 1;
    $oct2 = int(rand($range1)) + 1;
    $oct3 = int(rand($range1)) + 1;
    $oct4 = int(rand($range1)) + 1;

    ## Scanning private IP's and the loopback isn't
    ## usefull, so we filter them out.

    if ($oct1 == 127 || $oct1 == 172 || $oct1 == 192 || $oct1 == 10) {
        $ip = &randomIPGenerator();
    } else {
        ## Combine all the octals and create 1 valid IP address.
        $ip = "$oct1.$oct2.$oct3.$oct4";
    }
    return $ip;
}

#### getTarget ####
sub getTarget() {
    if ($rangeGe) {
        $target = rangeIPGenerator();
    } else {
        $target = randomIPGenerator();
    }
    return $target;
}    

#### Scanner ####
sub scanner() {
print "Scan started. Use -v to see some output.";
print "\n\n";

    while (1) {
        $target = getTarget();
        if ($verbose) {
            print " ---> SCANNING:  $target  <--- Hold steady. \n";
        }
        my $sock = new IO::Socket::INET(
        PeerAddr => $target,
        PeerPort => '23',
        Proto => 'tcp',
        Timeout => '3');
        if($sock) {

            print colored ("\n ---> SUCCES:  $target   <--- Good job. \n\n", 'red');
            open(DAT, ">>Succes.txt") || die("Error writing to file.");
            print DAT "--->  SUCCES:  $target \n";
            close(DAT);  
        }
        close($sock);
    }
}        

scanner();